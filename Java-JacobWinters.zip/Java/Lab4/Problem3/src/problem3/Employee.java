package problem3;

public class Employee 
{
    String employeeID, firstName, lastName, email;
    
    public String getID()
    {
        return employeeID;
    }
    
    public void setType(String employeeID)
    {
        this.employeeID = employeeID;
    }
    
    public String getfirstName()
    {
        return firstName;
    }
    
    public void setfirstName(String firstName)
    {
        this.firstName = firstName;
    }
    public String getlastName()
    {
        return lastName;
    }
    
    public void setlastName(String lastName)
    {
        this.lastName = lastName;
    }
    public String getemail()
    {
        return email;
    }
    
    public void setemail(String email)
    {
        this.email = email;
    }
    
    public Employee(String employeeID, String firstName, String lastName, String email) 
    {
        this.employeeID = employeeID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
    }
    public int compareTo(Employee sort)
    {
        if (lastName.compareTo(sort.lastName) > 0) 
        {
            return 1;
        } 
        else if (lastName.compareTo(sort.lastName) < 0)
        {
            return -1;
        }
        return 0;
    }
}
