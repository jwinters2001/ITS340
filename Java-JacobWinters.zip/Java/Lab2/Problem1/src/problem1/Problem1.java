
package problem1;

public class Problem1 {

    public static void main(String[] args) 
    {
        Student s1 = new Student();
        s1.setCredits(15);
        s1.setID(1);
        s1.setPoints(10);
        s1.setGPA(3.9);
        
        Student s2 = new Student();
        s2.setCredits(15);
        s2.setID(2);
        s2.setPoints(10);
        s2.setGPA(4.0);
        
        Student s3 = new Student();
        
        displayStudent(s1);
        displayStudent(s2);
        displayStudent(s3);
    }
    public static void displayStudent(Student s)
    {
        System.out.println("Student ID: " + s.getID() + " | Credit Hours: " + s.getCredits() + " | Points Earned: " + s.getPoints() + " | GPA: " + String.format("%.2f",s.getGPA()));

    }
    
}
