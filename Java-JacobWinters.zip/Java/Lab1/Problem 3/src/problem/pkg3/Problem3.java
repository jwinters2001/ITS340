package problem.pkg3;
import java.util.Scanner;

public class Problem3 
{
    public static void main(String[] args) 
    {
        int hours;
        int overtime = 0;
        int lvl;
        int ins;
        double lvl1 = 17;
        double lvl2 = 20;
        double lvl3 = 22;
        double gross_pay = 0;
        double net_pay = 0;
        double final_pay = 0;
        double rate;
        int ret;
        double deductions = 0;
        double deductions1 = 0;
        double deductions2 = 0;
        double test;
        
        Scanner input = new Scanner(System.in);
        System.out.print("Enter your Hours: ");
        hours = input.nextInt();
        System.out.print("Enter your Skill Level (1,2 or 3): ");
        lvl = input.nextInt();
        
        if (hours > 40)
        {
            overtime = hours - 40;
            hours = 40;
        }
        
        if (lvl == 1)
        {
            rate = 17;
            gross_pay = rate * hours + (overtime * rate * 1.5);
        }
        else if (lvl == 2)
        {
            rate = 22;
            gross_pay = rate * hours + (overtime * rate * 1.5);
        }
        else
        {
            rate = 22;
            gross_pay = rate * hours + (overtime * rate * 1.5);
        }
        
        
        
        if (lvl == 2 || lvl == 3)
        {
            System.out.print("Enter Insurance Option (1 = Medical, 2 = Dental, 3 = Long-Term Disability): ");
            ins = input.nextInt();
            if (ins == 1)
            {
                net_pay = gross_pay - 32.5;
                deductions1 = 32.5;
            }
            else if (ins == 2)
            {
                net_pay = gross_pay - 20;
                deductions1 = 20;
            }
            else if (ins == 3)
            {
                net_pay = gross_pay - 10;
                deductions1 = 10;
            }
            else
            {
                System.exit(0);
            }
        }
        
        
        
        if (lvl == 3)
        {
            System.out.print("Are you in the Retirment Plan? (1 for yes, 0 for no): ");
            ret = input.nextInt();
            if (ret == 1)
            {
                final_pay = net_pay * .97;
                deductions2 = net_pay * .03;
            }
            else
            {
                final_pay = net_pay;
            }
        }
        
        
        
        deductions = deductions1 + deductions2;
        System.out.print("Hours: " + hours + " Rate: "+ rate +
                " Normal Pay: $" + (hours * rate) + " Overtime Pay: $" + (overtime * rate * 1.5) + " Gross Pay: $" + gross_pay +
                " Total Deductions: $" + deductions + " final pay $" + final_pay);
    }
    
}
