package recording;
import java.util.Scanner;

public class Recording 
{

    public static void main(String[] args) 
    {
        Record[] list = new Record[5];
        Scanner input = new Scanner(System.in);
        int i = 0;
        int j = 0;
        for (i = 0; i < list.length; i++) 
        {
            j = i + 1;

            System.out.print("Enter song " + j + "'s title: ");
            String title = input.nextLine();
            System.out.print("Enter song " + j + "'s artist: ");
            String artist = input.nextLine();
            System.out.print("Enter song " + j + "'s playing time in seconds: ");
            String playingTimeString = input.nextLine();
            int playingTime = Integer.parseInt(playingTimeString);
            list[i] = new Record(title, artist, playingTime);
            System.out.println();
	}
		
	int sorter;
            do 
            {
		System.out.println("Sort by: 1) title 2) artist 3) playing time");
		sorter = input.nextInt();
		if (sorter > 0 && sorter < 4) 
                {
                    int a, b;
                    int highestVal = list.length - 1;
                    for (a = 0; a < highestVal; a++) 
                    {
			for (b = 0; b < highestVal; b++) 
                        {
                            int c = b + 1;
                            if (sorter == 1) 
                            {
                                if (list[b].getTitle().compareTo(list[c].getTitle()) > 0) 
                                {
                                    Record temp = list[b];
                                    list[b] = list[c];
                                    list[c] = temp;
				}
                            } 
                            else if (sorter == 2) 
                            {
				if (list[b].getArtist().compareTo(list[c].getArtist()) > 0) 
                                {
					Record temp = list[b];
					list[b] = list[c];
					list[c] = temp;
				}
                            } 
                            else if (sorter == 3) 
                            {

				if (list[b].getTime() > list[c].getTime()) 
                                {
                                    Record temp = list[b];
                                    list[b] = list[c];
                                    list[c] = temp;
				}
                            }
			}
                    }
		}
		else 
                {
                    System.out.println("Invalid choice. Please choose 1, 2, or 3.");
		}
            } 
            while (sorter < 1 || sorter > 3); 
            System.out.println();
            
            for (i = 0; i < list.length; i++) 
            {
		System.out.println("Song: " + list[i].getTitle() + " Artist: " + list[i].getArtist() + " Length: " + list[i].getTime());
            }
		
            input.close();

    }
    
}
