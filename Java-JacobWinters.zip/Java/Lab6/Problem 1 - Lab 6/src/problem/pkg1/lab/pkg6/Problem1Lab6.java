package problem.pkg1.lab.pkg6;

import java.util.Scanner;

public class Problem1Lab6 
{
    public static void main(String args[]) 
    {
        Scanner sc = new Scanner(System.in);
        Banner banner = new Banner();

        while(true) 
        {
            System.out.println("\nMain Menu");
            System.out.println("1. Add new Text to logo");
            System.out.println("2. Undo Changes logo");
            System.out.println("3. Display the current logo");
            System.out.println("4. Close");
            System.out.println("Enter:");
            int choice = sc.nextInt();

            switch (choice) 
            {
                case 1:
                    System.out.println("Enter new logo text:");
                    String s = sc.nextLine();
                    banner.create(sc.nextLine());
                    break;
                case 2:
                    banner.undo();
                    System.out.println("Undo Successfull.");
                    break;
                case 3:
                    banner.display();
                    break;
                case 4:
                    System.exit(0);
            }
        }
    }
}
    

