package problem.pkg3.lab.pkg6;
import java.util.*;

public class FoodOrder 
{
    ArrayList<Item> items = new ArrayList<Item>();

    public void addItem(int id, String name, double d, double e) 
    {
        Item item1 = new Item();

        item1.setId(id);
        item1.setItem(name);
        item1.setQuantity(d);
        item1.setPrice(e);
        items.add(item1);
    }

    public void listItem() 
    {
        for (Item itr : items) 
        {
            System.out.println("ID: " + itr.getId() + "| NAME: " + itr.getItem() + "| QUANTITY: " + itr.getQuantity() + "| PRICE: " + itr.getPrice());
        }
    }


    public void deleteItem(int id) 
    {

        int tester = 0;
        for (Item itr : items) 
        {
            if (itr.getId() == id) 
            {
                items.remove(itr);
                System.out.println("Deleted");
                tester = 1;
                break;
            }
        }
        if (tester == 0) {
            System.out.println("Not found");
        }
    }
}
