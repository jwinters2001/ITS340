package phonebook;
import java.util.Scanner;

public class PhoneBook {

    public static void main(String[] args) 
    {
        int n = 5;
        String[] names = { "Jacob", "Max",
                                "Nick", "Matt", "Lucas"};
        String[] number = { "219-713-1677", "219-713-1698",
                               "219-713-1874", "219-713-9874", "219-713-5674" };
        Scanner name = new Scanner(System.in);
        System.out.println("Enter a name to search the Array: ");
        String input = name.nextLine();
        int i = 0;
        while(i<5)
        {
            if (input.equals(names[i]))
            {
                System.out.println("Is in the Array");
                System.out.println("The Corresponding phone number is: " + number[i]);
                break;
            }
            else
            {
                System.out.println("Not in the Array");
                i = i+1;
            }
            
        }
    }
    
}
