package lab1ex1;
import java.util.Scanner;

public class Lab1Ex1 {

    public static void main(String[] args) 
    {
        final double DAY_RATE = 0.50;
        int weight;
        int days;
        double totalCost;
        
        Scanner input = new Scanner(System.in);
        System.out.print("Enter dog's weight in pounds: ");
        weight = input.nextInt();
        System.out.print("Enter the number of days to board: ");
        days = input.nextInt();
        totalCost = DAY_RATE * days * weight;
        
        System.out.println("The price to board a " + weight + "Pound dog for " +
              days + " day(s) is $" + String.format("%.2f", totalCost));
    }
    
}
