package problem.pkg2;
import java.util.Arrays;
import java.util.Scanner;

public class Problem2 
{
    public static void main(String[] args) 
    {
        Student s1 = new Student("Jacob", "Winters", 3.80);
        Student.School sc = new Student.School("PNW", "2200 169th St", "Hammond", "Indiana", "46323");
        System.out.println(s1);
        System.out.println(sc);
    }
    
}
