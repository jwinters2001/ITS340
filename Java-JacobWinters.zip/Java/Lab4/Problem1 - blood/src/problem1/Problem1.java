package problem1;

import static problem1.TestClass.patientDetails;

public class Problem1 
{

    public static void main(String[] args) 
    {
        Blood blood = new Blood("O", "-");
        Patient patient = new Patient(1, "Winters", "Jacob", blood);
        patientDetails(patient);
    }
    
}
