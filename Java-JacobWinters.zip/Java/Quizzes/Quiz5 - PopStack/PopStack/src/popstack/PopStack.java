package popstack;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.Scanner;

public class PopStack {


    public static void main(String[] args) 
    {
        LinkedList<String> stack = new LinkedList<String>();
        LinkedList<String> like = new LinkedList<String>();
        System.out.println("Enter all the cities that you have visited during the last year in the sequence that you have visited them");
        Scanner scan = new Scanner(System.in);
        int j = 0;
        for (;;) 
        {
            System.out.println("Enter city, Press Q to quit.");
            String input = scan.next();
            if (input.equals("Q")) 
            {
                break;
            }

            stack.push(input);
            String s = stack.pop();
            stack.push(s);
            System.out.println("Did you like " + s + "?");
            String input2 = scan.next();
            like.push(input2);
            j++;
        }

        for (int i = 0; i < j; i++)
        {
         System.out.println("City:"+ stack.get(i) + " | Liked: "+ like.get(i));
        }

    }
    
}
