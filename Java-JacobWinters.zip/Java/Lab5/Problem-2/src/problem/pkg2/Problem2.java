package problem.pkg2;
import java.util.LinkedList;
import java.util.Scanner;

public class Problem2 
{
    public static void main(String[] args) 
    {
        Scanner scan = new Scanner(System.in);
        Operations op = new Operations();
        op.storeNumbers(scan);
        
        LinkedList<Integer> list = new LinkedList <Integer>();
        list.add(14);
        list.add(-1);
        list.add(2);
        list.add(-9);
        list.add(11);
        list.add(6);
        op.MaxMin(list);
        op.sorter(list);
        op.orderedList(list, scan);
        op.removeNeg(list);
    }
}
