
package javaapplication8;

public class JavaApplication8 {

    public static void main(String[] args) 
    {
        int[] test = {1, 2, 3};
        
       for (int i=0; i<test.length; i++)
       {
          System.out.println("array pos " + i + " has value " + test[i]);
       }
       
    }
    
}
