package lab2ex1.classes;

public class Lab2Ex1Classes 
{

    public static void main(String[] args) 
    {
        Painting p1 = new Painting();
        p1.setArtist("Van Gogh");
        p1.setTitle("Stary Night");
        p1.setMedium("Oil");
        p1.setPrice(2000000);
        
        Painting p2 = new Painting();
        p2.setArtist("Da Vinci");
        p2.setTitle("Madonna on the Rocks");
        p2.setMedium("Oil");
        p2.setPrice(10000000);
        
        Painting p3 = new Painting("Stick Drawing", "GLS", "Crayon", .50);
        
        displayPainting(p1);
        displayPainting(p2);
        displayPainting(p3);
    }
    public static void displayPainting(Painting p)
    {
        System.out.println("Artist is " + p.getArtist() + 
                " and the gallery commision is $" + String.format("%.2f", p.getCommission()));
    }
}
