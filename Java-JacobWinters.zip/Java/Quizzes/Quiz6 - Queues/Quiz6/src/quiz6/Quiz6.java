package quiz6;
import java.util.LinkedList;
import java.util.Queue;
import java.util.*;

public class Quiz6
{
    public static void main(String[] args) 
    {
         Queue<Complaint> q = new LinkedList<Complaint>();
                Scanner scan = new Scanner(System.in);
                while(true) 
                {
                        System.out.print("Enter your name : ");
                        String name = scan.nextLine();
                        System.out.print("Enter your complain : ");
                        String complaint = scan.nextLine();

 
                        Complaint newComplaint = new Complaint(complaint, name);
                        q.add(newComplaint);


                        System.out.print("Do you have further complains ? (yes/no) : ");
                        String response = scan.nextLine();
                        if(response.equals("no"))
                                break;
                }

                while(!q.isEmpty()) 
                {
                        System.out.println(q.remove());
                }

                scan.close(); 
    }
}
