package lab5question3;

public class Lab5Question3 
{

    public static void main(String[] args) {
        LinkList theList = new LinkList();
        theList.insertFirst("Generic");
        theList.insertFirst("Generic1");
        theList.insertFirst("Generic2");
        theList.insertFirst("Generic3");
        theList.displayList();
        Link f = theList.find(44);
        if (f != null) 
        {
            System.out.println("Found with key " + f.data);
        }
        else 
        {
            System.out.println("Can't find link");
        }
        Link d = theList.delete(66);
        if (d != null) 
        {
            System.out.println("Deleted  with key " + d.data);
        } 
        else 
        {
            System.out.println("Can't delete link");
        }
        theList.displayList();
    }
}