package problem.pkg2.lab.pkg6;

public class Order 
{
    public String[] orderMenu = {"Burger", "Chicken Sandwhich", "Hotdog", "Fish Sandwich", "Peanut Butter and Jelly", "Chicken Wings",
        "Steak", "Ribs", "Tacos", "Grilled Chicken"};

    int orderMenuSize;
    int op;
    int[] order;

    Order() 
    {
        orderMenuSize = orderMenu.length;
        order = new int[6];
    }

    void displayMenu() 
    {
        int len = orderMenu.length;
        for (int i = 0; i < len; i++) {
            System.out.println((i + 1) + ". " + orderMenu[i]);
        }
    }
    
    int getItem()
    {
        return op;
    }
    
    void setItem(int op)
    {
        this.op = op;
    }

    void displayItem()
    {
        System.out.println(orderMenu[op - 1]);
    }
    int getSize() 
    {
        return orderMenuSize;
    }

    void setOrder(int[] x) 
    {
        order = x;
    }

    int[] getOrder() 
    {
        return order;
    }
}
