
package problem.pkg3.lab.pkg6;

public class Problem3Lab6 
{
    public static void main(String[] args) 
    {
       System.out.println("FOOD");
      
       FoodOrder f1 = new FoodOrder();

       f1.addItem(1,"Cereal",10,30);
       f1.addItem(2, "Juice", 5, 15);
      
       f1.listItem();
      
       System.out.println("GROCERY");

       GroceryOrder g1 = new GroceryOrder();

       g1.addItem(3, "Tooth Paste", 8, 7);
       g1.addItem(4, "Tylenol", 6, 15);
       g1.listItem();
       g1.deleteItem(2222);
       g1.listItem();
    }
}
