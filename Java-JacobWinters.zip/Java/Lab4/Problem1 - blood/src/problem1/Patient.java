package problem1;


public class Patient 
{
    int id;
    String last;
    String first;
    Blood blood;
    
    public int getID()
    {
        return id;
    }
    
    public void setID(int id)
    {
        this.id = id;
    }
    
    public String getLast()
    {
        return last;
    }
    
    public void setLast(String last)
    {
        this.last = last;
    }
    
    public String getFirst()
    {
        return first;
    }
    
    public void setFirst(String first)
    {
        this.first = first;
    }
    
    public Blood getBlood()
    {
        return blood;
    }
    
    public void setBlood(Blood blood)
    {
        this.blood = blood;
    }
    
    public Patient(int id, String last, String first, Blood blood)
    {
        this.id = id;
        this.last = last;
        this.first = first;
        this.blood = blood;
        
    }
    

}
