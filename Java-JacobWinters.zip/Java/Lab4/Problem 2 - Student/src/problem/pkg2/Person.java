
package problem.pkg2;

public class Person 
{
    private String first,last;
    Person(String first,String last)
    {
        this.first = first;
        this.last = last;
    }
}