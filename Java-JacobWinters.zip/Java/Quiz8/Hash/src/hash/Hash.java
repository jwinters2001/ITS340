package hash;
import java.util.*;
public class Hash {

    static void Hashing(int arr[])
        {
            HashMap<Integer, Integer> hmap = new HashMap<Integer, Integer>();

            for (int i = 0; i < arr.length; i++) {

                Integer c = hmap.get(arr[i]);

                if (hmap.get(arr[i]) == null) 
                    {
                        hmap.put(arr[i], 1);
                    }

                else 
                    {
                        hmap.put(arr[i], ++c);
                    }
                }

            System.out.println(hmap);
        }
        public static void main(String[] args)
        {
            Scanner s=new Scanner(System.in);
            int n;
            System.out.println("Enter the number of elements:");
            n=s.nextInt();
            int arr[];
            arr=new int[n];
            System.out.println("Enter the elements: ");
            for(int i=0;i<n;i++){
                arr[i]=s.nextInt();
            }
                Hashing(arr);
        }
    }
    
