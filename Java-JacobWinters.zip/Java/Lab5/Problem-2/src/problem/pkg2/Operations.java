package problem.pkg2;
import java.util.LinkedList;
import java.util.Scanner;

public class Operations 
{
    public static void storeNumbers(Scanner scan)
    {
        int num;
        LinkedList <Integer> list = new LinkedList<Integer>();
        while(true)
        {
            
            System.out.print("Enter a Positive number (0 to quit)");
            num = scan.nextInt();
            if (num > 0)
            {
                list.addLast(num);
            }
            else if(num == 0)
            {
                break;
            }
            else
            {
                System.out.println("Negative numbers are not added");
            }
                    
        }
        if(list.size() > 0 )
        {
            System.out.println("Linked List:");
            for (int i = 0; i < list.size(); i++)
            {
                System.out.print(list.get(i));
            }
        }
    }
    
    public static void sorter(LinkedList <Integer> list)
    {
        int min;
        for (int i = 1; i < list.size(); i++) {
            min = i;
            for (int j = i + 1; j < list.size(); j++) {
                if (list.get(j) < list.get(min)) {
                    min = j;
                }
            }
            if (min != i) {
                int temp = list.remove(i);
                list.add(min - 1, temp);
                temp = list.remove(min);
                list.add(i, temp);
            }
        }
        if (list.size() > 0) {
            System.out.println("Sorted List");
            for (int i = 1; i < list.size(); i++) {
                System.out.println(list.get(i));
            }
        }
    }
    
    public static void MaxMin(LinkedList <Integer> list)
    {
        int min;
        for (int i = 1; i < list.size() - 1; i++) 
        { 
            min = i;
            for(int j = i + 1; j < list.size(); j++)
            {
                if(list.get(j) < list.get(min))
                {
                    min = j;
                }
            }
            if(min != i)
            {
                int temp = list.remove(i);
                list.add(min - 1, temp);
                temp = list.remove(min);
                list.add(i, temp);
            }
        }
        System.out.println("");
        int j = list.size();
        int max = list.get(0);
        int min2 = list.get(j-1);
        System.out.println("Max: " + max);
        System.out.println("Min: " + min2);
    }
    public static void orderedList(LinkedList <Integer> list, Scanner scan)
    {
        int num;
        System.out.println("Enter a number to insert into linked list: ");
        num = scan.nextInt();
        int i;
        for(i = 0; i < list.size(); i++)
        {
            if(list.get(i) > num)
            {
                break;
            }
        }
        if(i == 0)
        {
            list.addFirst(num);
        }
        else if(i == list.size())
        {
            list.addLast(num);
        }
        else
        {
            list.add(i, num);
        }
        System.out.println("List after inserting: ");
        for (i = 0; i < list.size(); i++)
        {
            System.out.println(list.get(i));
        }
    }
    public static void removeNeg(LinkedList <Integer> list)
    {
        for (int i = 0; i < list.size();)
        {
            if(list.get(i) < 0)
            {
                list.remove(i);
            }
            else
            {
                i++;
            }
        }
        if(list.size() > 0)
        {
            for (int i = 0; i < list.size(); i++)
            {
                System.out.println("No Negatives: ");
                System.out.println(list.get(i));
            }
        }
    }
}
