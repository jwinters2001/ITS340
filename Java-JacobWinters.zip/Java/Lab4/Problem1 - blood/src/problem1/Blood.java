
package problem1;

public class Blood 
{
    String type;
    String rh;
    
    public String getType()
    {
        return type;
    }
    
    public void setType(String type)
    {
        this.type = type;
    }
    
    public String getRh()
    {
        return rh;
    }
    
    public void setRh(String rh)
    {
        this.rh = rh;
    }
    public Blood(String type, String rh)
    {
        this.type = type;
        this.rh = rh;
    }
}
