package problem2;
import java.util.Scanner;

public class Problem2 
{
    public static void main(String[] args) 
    {
        double GPA;
        int EACT;
        int SERV;
        double ACT;
        
        Scanner input = new Scanner(System.in);
        System.out.print("Enter Students GPA: ");
        GPA = input.nextDouble();
        System.out.print("Enter the number of Extracuricular Activities: ");
        EACT = input.nextInt();
        System.out.print("Enter the number of Service Activities: ");
        SERV = input.nextInt();
        
        ACT = EACT + SERV;
        
        if (GPA >= 3.8)
        {
            if (EACT >= 1)
            {
                if (SERV >= 1)
                {
                    System.out.print("Scholarship Candidate ");
                }
                else
                {
                    System.out.print("Not a Candidate ");
                }
            }
            else
            {
                System.out.print("Not a Candidate ");
            }
        }
        else if (GPA < 3.8 || GPA >= 3.4)
        {
            if (ACT >= 3)
            {
                    System.out.print("Scholarship Candidate ");
 
            }
            else
            {
                System.out.print("Not a Candidate ");
            }
        }
        
        else if (GPA < 3.4 || GPA >= 3.0)
        {
            if (EACT >= 2)
            {
                if (SERV >= 3)
                {
                    System.out.print("Scholarship Candidate ");
                }
                else
                {
                    System.out.print("Not a Candidate ");
                }
            }
            else
            {
                System.out.print("Not a Candidate ");
            }
        }
        else
        {
            System.out.print("Not a Candidate ");
        }
        
    }
    
}
