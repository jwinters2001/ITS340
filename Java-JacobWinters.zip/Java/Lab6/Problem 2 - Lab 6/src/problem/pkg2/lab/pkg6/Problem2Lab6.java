package problem.pkg2.lab.pkg6;
import java.util.Scanner;

public class Problem2Lab6 
{

    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);
        Order[] orderQueue = new Order[10];
        int orderNum = 0;
        char ch = '0';
        do {
            Order order = new Order();
            order.displayMenu();

            System.out.println("Please Select 6 items:");
            System.out.println("Enter items ordered:");

            int[] orderarr = new int[6];
            for (int i = 0; i < 6; i++) 
            {
                int x = sc.nextInt();
                if (x <= order.getSize() && x != 0) 
                {
                    orderarr[i] = x;
                } 
                else 
                {
                    System.out.println("Not Allowed: Please Enter within Menu limits!");
                    orderarr[i] = sc.nextInt();
                }
            }
            order.setOrder(orderarr);
            orderQueue[orderNum] = order;
            order = null;
            orderNum++;
            System.gc();
            System.out.println("New order?");
            ch = sc.next().charAt(0);
        } 
        while (ch == 'Y' || ch == 'y');
        
        orderNum = 0;
        ch = '0';
        do {
            if (orderQueue[orderNum] != null) 
            {
                Order order = new Order();
                int[] orderRetr = orderQueue[orderNum].getOrder();
                System.out.println("Next Items to be Made");
                for (int i = 0; i < orderRetr.length; i++) 
                {
                    int op = orderRetr[i];
                    order.setItem(op);
                    int j = i + 1;
                    System.out.print("Item " + j + ": ");
                    order.displayItem();
                }
                orderNum++;
                System.out.println("Retrieve Next Order");
                ch = sc.next().charAt(0);
            } 
            else 
            {
                System.out.println("No more orders. You are done for the day :)");
                break;
            }
        } 
        while (ch == 'Y' || ch == 'y');

        sc.close();
    
    }
    
}
