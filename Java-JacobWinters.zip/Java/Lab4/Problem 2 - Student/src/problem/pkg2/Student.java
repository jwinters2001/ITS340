package problem.pkg2;

public class Student
{
    private double gpa;
    private String schoolType;
    String first, last;

    Student(String first, String last, double gpa) 
    {
        this.first = first;
        this.last = last;
        this.gpa = gpa;
        
    }

    public String toString() 
    {
        return "Name: " + first + " "+ last + "\n" + "GPA : " + gpa + "\n";
    }

    static class School 
    {
        private String name, address, city, state, zipcode;

        School(String name, String address, String city, String state, String zipcode) {
            this.name = name;
            this.address = address;
            this.city = city;
            this.state = state;
            this.zipcode = zipcode;
        }

        public String toString() 
        {
            String msg = "";
            msg = msg + "School Name : " + name + "\n";
            msg = msg + "School Address : " + address + "\n";
            msg = msg + "School City : " + city + "\n";
            msg = msg + "School State : " + state + "\n";
            msg = msg + "School Zipcode : " + zipcode + "\n";
            return msg;
        }
    }
}

