
package practice.feb2;

public class PracticeFeb2 {

    public static void main(String[] args) 
    {
        Fiction book1 = new Fiction("Dune", "Frank Herbert", 29.95, "Science Fiction");
        book1.displayBookinfo();
    }
    
}
