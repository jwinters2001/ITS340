package bank;

import static bank.BankAccount.explainAccountPolicy;
import java.util.Scanner;

public class Bank {

 public static void main(String[] args) 
    {
        BankAccount s1 = new BankAccount();
        BankAccount s2 = new BankAccount();
        BankAccount s3 = new BankAccount();
        BankAccount s4 = new BankAccount();
        
        s1 = getData();
        s2 = getData();
        s3 = getData();
        
        System.out.println("===========================================================================================");
        
        explainAccountPolicy();
        
        showData(s1);
        showData(s2);
        showData(s3);
        showData(s4);

        
    }
    public static BankAccount getData()
    {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter your Name: ");
        String name = input.nextLine();
        System.out.print("Enter Account Number: ");
        int accountID = input.nextInt();
        System.out.print("Enter your Balance: ");
        int Balance = input.nextInt();
        
        return new BankAccount(name, accountID, Balance);
    }
    public static void showData(BankAccount s)
    {
        System.out.println("Account Number: " + s.getID() + " | Name: " + s.getName() + " | Balance: $" + s.getBalance());
        s.deductmonthlyfee();
        System.out.println("With Upcoming Monthly Deduction");
        System.out.println("---------------------------------------------------------------------------------------------");
        System.out.println("Account Number: " + s.getID() + " | Name: " + s.getName() + " | Balance: $" + s.getBalance());
    }
    
}
