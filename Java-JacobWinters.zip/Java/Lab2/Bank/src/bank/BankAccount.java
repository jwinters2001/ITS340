package bank;

public class BankAccount 
{
    private int accountID;
    private String name;
    private int balance;
    
    public BankAccount()
    {
        this.accountID = 0;
        this.name = "";
        this.balance = 0;
    }
    public BankAccount(String name, int accountID, int balance)
    {
        this.name = name;
        this.accountID = accountID;
        this.balance = balance;
    }
    public int getID()
    {
        return accountID;
    }
    public void setID(int ID)
    {
        accountID = ID;
    }
    public String getName()
    {
        return name;
    }
    public void setName(String Name)
    {
        this.name = Name;
    }
    public int getBalance()
    {
        return balance;
    }
    public void setBalance(int Balance)
    {
        this.balance = Balance;
    }

    public void deductmonthlyfee()
    {
        final int fee = 4;
        balance = balance - fee;

    }
    
    public static void explainAccountPolicy()
    {
        System.out.println("Dear valued customer to maintain our systems a $4 service fee is taken from your account each month");
    }

}
