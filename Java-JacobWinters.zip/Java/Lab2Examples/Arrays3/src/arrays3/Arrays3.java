package arrays3;
import javax.swing.JOptionPane;

public class Arrays3 
{

    public static void main(String[] args) 
    {
        String[] itemNames = {"table", "desk", "Dresser", "Entertainment Center"};
        double[] itemPrices = {250.39, 325.00, 475.00, 555.25};
        
        String selection;
        String menu = "Enter a product selection: ";
        boolean isMatch = false;
        int matchIndex=0;
        
        //display menu
        selection = JOptionPane.showInputDialog(null, menu);
        selection = selection.toLowerCase();
    
    for (int i=0; i < itemNames.length; i++)
    {
        menu = menu + "\n " + itemNames[i];
    }
    
    for (int i=0; i < itemNames.length; i++)
    {
        if (selection.equals(itemNames[i]))
        {
            isMatch = true;
            matchIndex = i;
                   
        }
    }
    if (isMatch)
    {
        JOptionPane.showMessageDialog(null, "The price of the selected item =" + itemPrices[matchIndex]);
    }
    else JOptionPane.showMessageDialog(null, "No entry found;");
    }
    
}
