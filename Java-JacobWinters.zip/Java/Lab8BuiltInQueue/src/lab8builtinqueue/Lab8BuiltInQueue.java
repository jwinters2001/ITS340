package lab8builtinqueue;

import java.util.*;

public class Lab8BuiltInQueue
{

    public static void main(String[] args) 
    {
        Queue<String> waitingQueue = new LinkedList<>();
        
        //add new elements to the Queue (Enqueue operation).
        waitingQueue.add("Joe");
        waitingQueue.add("Mark");
        waitingQueue.add("Susan");
        
        System.out.println("Waiting Queue: " + waitingQueue);
        
        //Process the queue by getting the next item in line.(Dequeue).
        String name = waitingQueue.remove();
        System.out.println("Dequeued item: " + name);
        System.out.println("Waiting Queue: " + waitingQueue);
        
        name = waitingQueue.remove();
        System.out.println("Dequeued item: " + name);
        System.out.println("Waiting Queue: " + waitingQueue);
        
        waitingQueue.add("Sharyl");
        System.out.println("Waiting Queue: " + waitingQueue);
        
        //Process queue using pull method which returns a null when queue is empty.
        name = waitingQueue.poll();
        System.out.println("Dequeued item: " + name);
        System.out.println("Waiting Queue: " + waitingQueue);
        
        name = waitingQueue.poll();
        System.out.println("Dequeued item: " + name);
        System.out.println("Waiting Queue: " + waitingQueue);
    }
    
}
