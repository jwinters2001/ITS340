package lab8customqueue1;

import java.util.*;

public class GenericQueue<E> 
{
    private LinkedList<E> list = new LinkedList<>();
    
    public void enqueue(E item)
    {
        list.addLast(item);
    }
    
    public E dequeue()
    {
        return list.removeFirst();
    }
    
    public int size()
    {
        return list.size();
    }
    
    public E getQNodeData(int i)
    {
        return list.get(i);
    }
    
    public E getLastInQueue()
    {
        return list.getLast();
    }
    public E getFirstInQueue()
    {
        return list.getFirst();
    }
}
