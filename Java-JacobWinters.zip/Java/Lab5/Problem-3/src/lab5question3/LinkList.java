package lab5question3;

public class LinkList<T> 
{

    private Link first;

    public LinkList()
    {
        first = null;
    }

    public void insertFirst(T data) 
    { 
        Link newLink = new Link(data);
        newLink.next = first;
        first = newLink;
    }

    public Link find(T data)
    {
        Link current = first;
        while (current.data != data)
        {
            if (current.next == null)
            {
                return null;
            } 
            else
            {
                current = current.next;
            }
        }
        return current;
    }

    public Link delete(T data)
    { 
        Link current = first; 
        Link previous = first;
        while (current.data != data) 
        {
            if (current.next == null) 
            {
                return null;
            } 
            else 
            {
                previous = current;
                current = current.next;
            }
        } 
        if (current == first)
        {
            first = first.next;
        } 
        else
        {
            previous.next = current.next;
        }
        return current;
    }

    public void displayList()
    {
        System.out.print("List: ");
        Link current = first;
        while (current != null)
        {
            current.displayLink();
            current = current.next;
        }
        System.out.println("");
    }
}

