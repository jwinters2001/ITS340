package quiz2.arrays;
import java.util.Arrays;
public class Quiz2Arrays 
{
    public static void main(String[] args) 
    {
        final int SIZE = 5;

        String[] people = {"Jacob", "Brandon", "Luke", "Max", "Nick"};
        
        Arrays.sort(people);
        
        for (int i=0; i < SIZE; i++)
        {
            System.out.println("Name: " + people[i]);
        }
    }
}
