package practice.feb2;

public class Fiction extends Book 
{
    private String fictionType;
  
    public Fiction(String title, String author, double price, String fictionType)
    {
       super(title, author, price);
        //super.setTitle(title);
        //super.setAuthor(author);
        //super.setPrice(price);
        this.fictionType = fictionType;
    }
    public String getFictionType()
    {
        return fictionType;
    }
    public void setFictionType(String fictionType)
    {
        this.fictionType = fictionType;
    }
    public void displayBook()
    {
        System.out.println("The type of ficiton book is " + getFictionType());
    }
    
    @Override
    public String announceBook()
    {
        return "This book is a FICTIONAL book";
    }
}
