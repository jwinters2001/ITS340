package quiz1.circle;
import java.util.Scanner;

public class Quiz1Circle {

public static void main(String[] args) 
{

    Scanner input = new Scanner(System.in);

    System.out.print("Enter the radius of a circle: ");
    double radius = input.nextDouble();

    input.close();

    Circle c = new Circle();
    Circle c1 = new Circle(radius);

    System.out.println("Area is " + c1.getArea());
    System.out.println("Diameter is " + c1.getDiameter());
    System.out.println("Circumference is " + c1.getCircumference());

}
}
