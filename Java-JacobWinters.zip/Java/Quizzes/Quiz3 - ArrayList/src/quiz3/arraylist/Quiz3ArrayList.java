package quiz3.arraylist;
import java.util.Scanner;
import java.util.Arrays;   
public class Quiz3ArrayList 
{
    public static void main(String[] args) 
    {
        Scanner s = new Scanner(System.in);

        int arr[]=new int[5];

        System.out.println("enter elements");

        for(int i=0;i<5;i++)
        {
            arr[i]=s.nextInt();
        }
        
        System.out.println("=====================");
        for(int i: arr)
        { 

            System.out.println(i);

        }
        Arrays.sort(arr);
        System.out.println("Lowest: " + arr[0]);
        System.out.println("Highest: " + arr[4]);
        double avg = (arr[0] + arr[1] + arr[2] + arr[3] + arr[4]);
        avg = avg / 5;
        System.out.println("Average: " + avg);
    }
}
