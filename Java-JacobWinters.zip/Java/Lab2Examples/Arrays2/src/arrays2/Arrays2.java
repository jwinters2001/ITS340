package arrays2;


public class Arrays2 
{
    public static void main(String[] args) 
    {
        final int SIZE = 2;
        //Declare array of student bjects and allocate memory for two objects
        Student[] objArr = new Student[SIZE];
        
        // Initialize first element in the object array
        objArr[0] = new Student("Doe", "John", 3.75);
        objArr[1] = new Student("Doe", "Jane", 3.9);
        
        System.out.println("Student 1 Last name is " + objArr[0].getLastName());
        
        //print out all content in the array
        for (Student s: objArr)
        {
            System.out.println("Student " + s.getFirstName() + " " + s.getLastName() + " Has GPA of " + s.getGPA());
        }
    }
    
}
