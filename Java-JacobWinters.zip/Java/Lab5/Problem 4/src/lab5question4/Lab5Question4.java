package lab5question4;

public class Lab5Question4 {

    public static void main(String[] args)
    {
        LinkList theList = new LinkList(); 
        theList.insertFirst(5, 2.99);
        theList.insertFirst(6, 7.99);
        theList.insertFirst(4, 5.99);
        theList.insertFirst(2, 6.99);
        theList.insertFirst(1, 8.99);
        theList.displayList();
        Link f = theList.find(5);
        if (f != null) 
        {
            System.out.println("Found with key " + f.iData);
        } else 
        {
            System.out.println("Can't find");
        }
        Link d = theList.delete(5);
        if (d != null) 
        {
            System.out.println("Deleted with key " + d.iData);
        } 
        else {
            System.out.println("Can't delete");
        }
        theList.displayList();
    }
    
}
