package problem.pkg3.lab.pkg6;

public class Item 
{

   private int id;
   private String item;
   private double quantity;
   private double price;
  

   public int getId() 
   {
       return id;
   }
   public void setId(int id) 
   {
       this.id = id;
   }
   public String getItem() 
   {
       return item;
   }
   public void setItem(String item) 
   {
       this.item = item;
   }
   public double getQuantity() 
   {
       return quantity;
   }
   public void setQuantity(double quantity) 
   {
       this.quantity = quantity;
   }
   public double getPrice() 
   {
       return price;
   }
   public void setPrice(double price) 
   {
       this.price = price;
   }
   
}
