package problem.pkg1.lab.pkg6;

import java.util.*;

public class Banner 
{
    static Stack<String> stack = new Stack<String>();
    static int top = -1;

    void create(String s) 
    {
        top += 1;
        stack.add(s);
    }


    void undo() 
    {
        stack.remove(top);
        top -= 1;
    }

    void display() 
    {
        System.out.println("Current Banner is: " + stack.get(top).toString());
    }

    
}
