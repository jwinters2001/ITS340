
package quiz4;
import java.util.*;
import java.util.Scanner;
public class Quiz4 {

    public static void main(String[] args)
    {
        LinkedList<String> Q = new LinkedList<String>(List.of("Name", "Age", "Experience"));
        LinkedList<String> A = new LinkedList<String>();
        
        for (int i = 0; i < Q.size(); i++)
        {
            Scanner input = new Scanner(System.in);
            System.out.println(Q.get(i));
            String answer = input.nextLine();
            A.add(answer);
        }
        
        System.out.println(Q.get(0) + ": " + A.get(0) + " " + 
                Q.get(1) + ": " + A.get(1) + " " + Q.get(2) + ": " + A.get(2));
    }
    
}
