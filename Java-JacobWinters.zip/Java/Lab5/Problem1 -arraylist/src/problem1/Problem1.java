
package problem1;
import java.util.ArrayList;
public class Problem1 
{
    public static void main(String[] args) 
    {
        ArrayList<String> categories = new ArrayList<String>();
        MovieIO movie = new MovieIO();
        ArrayList<Movie> array = movie.getMovies();
        
        for(int i = 0; i < array.size(); i++)
        {
            categories.add(array.get(i).getCategory());
        }
        
        System.out.println("+=+=+= Categories =+=+=+");
        for(int i = 0; i<categories.size(); i++)
        {
            System.out.println(categories.get(i));
        }
    }
    
}
