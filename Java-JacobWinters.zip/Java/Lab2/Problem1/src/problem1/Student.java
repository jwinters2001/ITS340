package problem1;

public class Student 
{
    private int studentID;
    private int credits;
    private int points;
    private double gpa;
    private double calculate;
    
    public Student(int studentID)
    {
        this.studentID = studentID;
    }
    public Student()
    {
        this.studentID = 9999;
        this.credits = 3;
        this.points = 12;
        this.gpa = points / credits;
    }
    public int getID()
    {
        return studentID;
    }
    public void setID(int ID)
    {
        studentID = ID;
    }
    public int getCredits()
    {
        return credits;
    }
    public void setCredits(int creds)
    {
        this.credits = creds;
    }
    public int getPoints()
    {
        return points;
    }
    public void setPoints(int point)
    {
        this.points = point;
    }
    public double getGPA()
    {
        return gpa;
    }
    public void setGPA(double GPA)
    {
        this.gpa = GPA;
        calculate = points / credits;
    }
    public double getCalculate()
    {
        return calculate;
    }

}