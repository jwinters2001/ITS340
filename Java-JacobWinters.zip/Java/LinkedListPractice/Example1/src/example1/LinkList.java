package example1;

public class LinkList 
{
    private Link first; //reference to the first link on the list
    
    public LinkList()
    {
        first = null;
        
    }
    public void insertFirst(int iData)
    {
        Link newLink = new Link(iData);
        newLink.next = first;
        first = newLink;
    }
    public Link find(int key)
    {
        Link current = first;
        while(current.iData != key)
        {
            if(current.next == null)
            {
                return null;
            }
            else
            {
                current = current.next;
            }
        }
        return current;
    }
    public void displayList()
    {
        System.out.print("List (first-->Last: ");
        Link current = first;
        while(current != null)
        {
            current.displayLink();
            current = current.next;
        }
        System.out.println();
    }
}
