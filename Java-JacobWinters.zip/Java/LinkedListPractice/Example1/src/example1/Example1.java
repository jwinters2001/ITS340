
package example1;

public class Example1 
{

    public static void main(String[] args) 
    {
        LinkList theList = new LinkList();
        
        theList.insertFirst(11);
        theList.insertFirst(22);
        theList.insertFirst(33);
        
        theList.displayList();
        
        Link f = theList.find(22);
        if (f != null)
        {
            System.out.println("Found link with key " + f.iData);
        }
        else
        {
            System.out.println("Data not found");
        }
    }
    
}
