package problem1;
import java.util.ArrayList;
public class MovieIO 
{
    public ArrayList <Movie> getMovies()
    {
        ArrayList <Movie> movies = new ArrayList<Movie>();
        movies.add(new Movie("Harry Potter","Magic film"));
        movies.add(new Movie("Goonies","Adventure film"));
        movies.add(new Movie("Iron Man","Action film"));
        movies.add(new Movie("Batman","Horror film"));
        return movies;
    }
    
}
