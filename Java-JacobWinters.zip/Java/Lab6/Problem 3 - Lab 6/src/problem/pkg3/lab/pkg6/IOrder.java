package problem.pkg3.lab.pkg6;

public interface IOrder 
{
   public void addItem(int id,String item,double quantity,double price);
   public void listItem();
   public void deleteItem(int id);
}
