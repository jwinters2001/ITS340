package lab1ex2;
import javax.swing.*;
public class Lab1Ex2 
{

    public static void main(String[] args) 
    {
        int number;
        String entry, message;
        final int QUIT = 999;
        
        entry = JOptionPane.showInputDialog(null, "Enter a number or " + 
                QUIT + " to quit");
        
        number = Integer.parseInt(entry);
        
        while(number != QUIT)
        {
                if (number % 2 == 0)
                {
                    message = "You typed in an even number";
                }
                else
                {
                   message = "You typed in an odd number";
                }
                JOptionPane.showMessageDialog(null, message);
                entry = JOptionPane.showInputDialog(null, "Enter an even number or " + QUIT + "to quit");
                number = Integer.parseInt(entry);
    }
}
}
