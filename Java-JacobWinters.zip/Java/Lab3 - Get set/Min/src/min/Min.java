package min;

import java.util.Arrays;
import java.util.Scanner;

public class Min
{
    public static void main(String[] args) 
    {

        Scanner obj = new Scanner(System.in);
        double arr[] = new double [10];
        int size = 0;
        System.out.println("Enter numbers: ");
        while (size < 10)
        {
            String quit = obj.next();
            if(quit.equals("QUIT"))
            {
                break;
            }
            else if(size >= 10)
            {
                break;
            }
            else
            {
                arr[size++] = Integer.parseInt(quit);
            }
        }
        
        Arrays.sort(arr);
        System.out.println("After sorting");
        for(int i = 0; i < size; i++)
        {
            System.out.print(arr[i]+" ");
        }
        System.out.println();
        
        double sum = 0;
        for(int i=0; i<size; i++)
        {
            sum += arr[i];
        }
        double avg = sum/size;
        System.out.println("Average is " + avg);
        ArrayMethods minimum = new ArrayMethods();
        double min = minimum.getMin(arr);
        System.out.println("Minimum is " + min);
        System.out.println("Difference from average:");
        for (int i = 0; i < size; i++)
        {
            double dif = arr[i] - avg;
            System.out.println(arr[i] + " : " + Math.abs(dif));
        }

        double [] marr = minimum.removeMin(arr);
        System.out.println("New Array");
        for(int i = 0; i < marr.length; i++)
        {
            System.out.println(marr[i]);
        }
    }
    
}

