package lab5question3;

public class Link<T> 
{
    public T data;
    public Link next;

    public Link(T data)
    {
        this.data = data;
    }

    public void displayLink()
    {
        System.out.print(data + " ");
    }
}
