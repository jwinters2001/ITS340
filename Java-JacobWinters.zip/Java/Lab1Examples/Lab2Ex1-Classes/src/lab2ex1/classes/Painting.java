package lab2ex1.classes;

public class Painting 
{
    private String title;
    private String artist;
    private String medium;
    private double price;
    private double galleryCommission;
    public final static double Rate = 0.20;
    
    public Painting()
    {
        galleryCommission = 0.0;
    }
    public Painting(String title)
    {
        this.title = title;
    }
    public Painting(String title, String artist, String medium, double price)
    {
        this.title = title;
        this.artist = artist;
        this.medium = medium;
        this.price = price;
        this.galleryCommission = price * Rate;
    }
    public String getTitle()
    {
        return title;
    }
    public void setTitle(String artTitle)
    {
        title = artTitle;
    }
    public String getArtist()
    {
        return artist;
    }
    public void setArtist(String artist)
    {
        this.artist = artist;
    }
    public String getMedium()
    {
        return medium;
    }
    public void setMedium(String medium)
    {
        this.medium = medium;
    }
    public double getPrice()
    {
        return price;
    }
    public void setPrice(double price)
    {
        this.price = price;
        galleryCommission = price * Rate;
    }
    public double getCommission()
    {
        return galleryCommission;
    }

}
