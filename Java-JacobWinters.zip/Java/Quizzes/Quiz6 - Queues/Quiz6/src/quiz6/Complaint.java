package quiz6;

public class Complaint 
{
        private String complain;
        private String name; 
        public Complaint(String complain, String name) 
        {
                this.complain = complain;
                this.name = name;
        }
        public String getComplain() 
        {
                return complain;
        }
        public void setComplain(String complain) 
        {
                this.complain = complain;
        }
        public String getName() 
        {
                return name;
        }
        public void setName(String name) 
        {
                this.name = name;
        }
        public String toString() 
        {
                String s = "\nName : "+this.name+"\nComplaint : "+this.complain;
                return s;
        }
}
