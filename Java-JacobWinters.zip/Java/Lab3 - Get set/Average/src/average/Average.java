package average;
import java.util.Scanner;
import java.util.Arrays;

public class Average {

    public static void main(String[] args) 
    {
        Scanner obj = new Scanner(System.in);
        double arr[] = new double [10];
        int size = 0;
        System.out.println("Enter numbers: ");
        while (size < 10)
        {
            String quit = obj.next();
            if(quit.equals("QUIT"))
            {
                break;
            }
            else if(size >= 10)
            {
                break;
            }
            else
            {
                arr[size++] = Integer.parseInt(quit);
            }
        }
        Arrays.sort(arr);
        System.out.println("After sorting");
        for(int i = 0; i < size; i++)
        {
            System.out.println(arr[i]+" ");
        }
        System.out.println();
        
        double sum = 0;
        for(int i=0; i<size; i++)
        {
            sum += arr[i];
        }
        double avg = sum/size;
        System.out.println("Average is " + avg);
        
        System.out.println("Difference from average:");
        for (int i = 0; i < size; i++)
        {
            double dif = arr[i] - avg;
            System.out.println(arr[i] + " : " + Math.abs(dif));
        }
        
        System.out.println("Enter the Number to search the array for: ");
        double number = obj.nextDouble();
        bin ob = new bin();
        int result = ob.binarysearch(size, number, arr);
        if (result == -1)
        {
             System.out.println("Element not present");
        }
        else
        {
            System.out.println("Element found at "
                               + "index " + result);
        }
        
    }   
}
