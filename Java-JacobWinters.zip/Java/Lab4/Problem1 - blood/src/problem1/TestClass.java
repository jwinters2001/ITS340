package problem1;

public class TestClass 
{
    static void patientDetails(Patient patient)
    {
        System.out.println("Patient ID: " + patient.getID());
        System.out.println("Name: " + patient.getFirst() + " " + patient.getLast());
        System.out.println("Blood type: " + patient.getBlood().getType() 
                +  " " + patient.getBlood().getRh());
    }
}
