package problem3;
import java.util.Arrays;
import java.util.Scanner;

public class Problem3 
{
    public static void main(String[] args) 
    {
       Scanner input = new Scanner(System.in);
       Employee[] employees = new Employee[3];
       for (int i = 0; i < employees.length; i++) {
           System.out.print("Enter the employeeID: ");
           String employeeID = input.next();
           System.out.print("Enter the firstName: ");
           String firstName = input.next();
           System.out.print("Enter the lastName: ");
           String lastName = input.next();
           System.out.print("Enter the email: ");
           String email = input.next();
           employees[i] = new Employee(employeeID, firstName, lastName, email);
       }
       
       for (int i = 0; i < employees.length; i++)
       {
           System.out.println("ID: " + employees[i].getID() + ", " + "Name: " + employees[i].getfirstName() + " " + employees[i].getlastName()
                   + ", " + "Email: " + employees[i].getemail());
       }
    }
}
    
