
package recording;

class Record 
{
    String title;
    String artist;
    int Time;
		
    public String getTitle() 
    {
        return title;
    }

    public void setTitle(String title) 
    {
        this.title = title;
    }

    public String getArtist() 
    {
        return artist;
    }

    public void setArtist(String artist) 
    {
        this.artist = artist;
    }

    public int getTime() 
    {
        return Time;
    }

    public void setTime(int i) 
    {
        this.Time = i;
    }

    public Record(String title, String artist, int Time) 
    {
        this.title = title;
        this.artist = artist;
        this.Time = Time;
    }
}
