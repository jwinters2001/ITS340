package problem4;
import java.util.Arrays;
import java.util.Random;
public class Problem4 {

    public static void main(String[] args) 
    {
        int[] array = new int[]{2,6,1,0,9,3,10,11,15,69};
        int[] array2 = new int[]{10,9,8,7,6,5,4,3,2,1};
        Random random = new Random();

        int[] array_c = array.clone();
        int comparisions = 0;
        int copies = 0;

        for (int i = 1; i < 10; i++) 
        { 
            int key = array[i]; 
            copies++;
            int j = i - 1; 
            while (j >= 0 && array_c[j] < key) 
            { 
                array_c[j + 1] = array_c[j];
                copies++;
                j = j - 1;
                comparisions ++;
            }
            comparisions ++;
            array_c[j + 1] = key;
            copies++;
        }
        
        int[] array_c2 = array2.clone();
        int comparisions2 = 0;
        int copies2 = 0;
        
        for (int i = 1; i < 10; i++) 
        { 
            int key = array2[i]; 
            copies2++;
            int j = i - 1; 
            while (j >= 0 && array_c2[j] < key) 
            { 
                array_c2[j + 1] = array_c2[j];
                copies2++;
                j = j - 1;
                comparisions2 ++;
            }
            comparisions2 ++;
            array_c2[j + 1] = key;
            copies2++;
        } 
        System.out.println("Generated Array");
        System.out.println(Arrays.toString(array));
        System.out.println();
        System.out.println("Sorted Array");
        System.out.println(Arrays.toString(array_c));
        System.out.println();
        System.out.println("Comparisons : " + comparisions);
        System.out.println();
        System.out.println("Copies : " + copies);
        System.out.println("++++++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("Generated Array 2");
        System.out.println(Arrays.toString(array2));
        System.out.println();
        System.out.println("Sorted Array 2");
        System.out.println(Arrays.toString(array_c2));
        System.out.println();
        System.out.println("Comparisons : " + comparisions2);
        System.out.println();
        System.out.println("Copies : " + copies2);
    }
    
}
