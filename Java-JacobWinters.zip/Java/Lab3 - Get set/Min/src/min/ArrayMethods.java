package min;

import java.util.Arrays;

public class ArrayMethods 
{
    public static double getMin(double [] arr)
    {
        double minimum = arr[0];
        
        for (int i=1; i<arr.length; i++)
        {
            if(arr[i] < minimum)
            {
                minimum = arr[9];
            }
        }
        return minimum;
    }
    public static double [] removeMin(double [] arr)
    {
        double minimums = arr[0];
        System.out.println(minimums);
        double [] marr = new double[9];
        for (int i = 0, j = 0; i < 10; i++) 
        {
            if (i == minimums) 
            {
            }
            else
            {
               marr[j++] = arr[i];
            }
        }
        return marr;
    }
}



