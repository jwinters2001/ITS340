package lab8customqueue1;

public class Lab8CustomQueue1 
{

    public static void main(String[] args) 
    {
        GenericQueue<String> queue1 = new GenericQueue<>();
        queue1.enqueue("Jane");
        queue1.enqueue("Sharyl");
        queue1.enqueue("Tom");
        
        displayQueue(queue1);
        System.out.println("First item in Queue: " + queue1.getFirstInQueue());
        System.out.println("Last item in Queue: " + queue1.getLastInQueue());
        displayQueue(queue1);
        //Process queue by getting the first item in Queue
        //and deleting it from the queue
        String name = queue1.dequeue();
        displayQueue(queue1);
        
        //process entire Queue
        processQueue(queue1);
        displayQueue(queue1);
    }
    
    public static void displayQueue(GenericQueue<String> q)
    {
        System.out.println("\nElements in Queue: ");
        for (int i = 0; i<q.size(); i++)
        {
            System.out.println(q.getQNodeData(i) + " ");
        }
        System.out.println("");
    }
    
    public static void processQueue(GenericQueue<String> q)
    {
        while (q.size() > 0)
        {
            System.out.println(q.dequeue());
        }
    }
    
}
