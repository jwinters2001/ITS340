package arrays2;

public class Student 
{
    private String lastName;
    private String firstName;
    private double GPA;
    
    public Student(String lastName, String firstName, double GPA)
    {
        this.lastName = lastName;
        this.firstName = firstName;
        this.GPA = GPA;
    }
    public String getLastName()
    {
        return lastName;
    }
    public String getFirstName()
    {
        return firstName;
    }
    public double getGPA()
    {
        return GPA;
    }
}
